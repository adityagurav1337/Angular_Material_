import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ToggleComponent } from './toggle/toggle.component';
import { SnackBarComponent } from './snack-bar/snack-bar.component';
import { BadgeComponent } from './badge/badge.component';
import { CheckboxComponent } from './checkbox/checkbox.component';
import { ListComponent } from './list/list.component';

const routes: Routes = [
  {path:"toggle", component:ToggleComponent},
  {path:"snack", component:SnackBarComponent},
  {path:"badge", component:BadgeComponent},
  {path:"checkbox", component:CheckboxComponent},
  {path:"list", component:ListComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
